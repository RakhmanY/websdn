export interface Dimensions {
    width: number;
    height: number;
}
